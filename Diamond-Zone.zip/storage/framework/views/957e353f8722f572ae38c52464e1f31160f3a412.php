

<?php $__env->startSection('content'); ?>
		<div class="row mt-4">

				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
						<div class="d-block mb-4 mb-md-0">

								<h2 class="h4">Create New Sub Category</h2>

						</div>

				</div>
				<div class="col-6 mb-4">
						<div class="card border-0 shadow components-section">
								<div class="card-body">
										<div class="row mb-4">
												<form action="<?php echo e(route('subcategories.store')); ?>" method="POST" enctype="multipart/form-data">
														<?php echo csrf_field(); ?>
														<div class="col-lg-12 col-sm-6">

																<div class="mb-4">
                                                                    <label class="my-1 me-2" for="country">Main Category</label>
                                                                        <select name="category_id"
																				class="form-select  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
																				<option value="">Select main category</option>
                                                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																				    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

																		</select>

                                                                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
																				<small class="form-text text-danger"><?php echo e($message); ?></small>
																		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>

																<div class="mb-4">
																		<label for="email">Sub Category Name</label>
																		<input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
																				id="subcategory_name">
																		<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
																				<small class="form-text invalid-feedback"><?php echo e($message); ?></small>
																		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
																</div>

																<div class="mb-4">
																		<label for="email">Category Slug</label>
																		<input type="text" name="slug" class="form-control" id="subcategory_slug" readonly>

																</div>

																<div class="mt-3">
																		<button type="submit" class="btn btn-gray-800 mt-2 animate-up-2">Save All</button>
																</div>
														</div>
												</form>

										</div>

								</div>
						</div>
				</div>
		</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
		<script>
		  var category_name = document.getElementById('subcategory_name');
		  var category_slug = document.getElementById('subcategory_slug');

		  category_name.addEventListener('keyup', function() {
		    category_slug.value = slugify(category_name.value)
		  })
		</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_project\Diamond-Zone\resources\views/admin/subcategories/create.blade.php ENDPATH**/ ?>