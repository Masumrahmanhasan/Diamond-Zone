<?php $__env->startSection('content'); ?>
<div class="section_gaps"></div>


<section id="user_dashboard">

    <div class="container">

        <div class="row">

            
            <?php echo $__env->make('theme.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            

            <div class="col-lg-9">

                <div class="user_dashboard_details">

                    <div class="dashboard">
                        <h3>Your Orders</h3>
                    </div>

                    <div class="orders_list">

                        <table class="table table-bordered">

                            <thead>
                                <tr>
                                    <th>Order</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Total</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($order->order_code); ?></td>
                                        <td><?php echo e($order->created_at); ?></td>
                                        <td><span class="badge <?php echo e(\App\Models\Order::STATUS[$order->status]['label']); ?>"><?php echo e(\App\Models\Order::STATUS[$order->status]['value']); ?></span></td>
                                        <td><?php echo e(number_format($order->grand_total, 2)); ?></td>
                                        <td>
                                            <a href="" class="btn btn-info btn-sm text-white">view</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>

<div class="section_height"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_project\Diamond-Zone\resources\views/theme/user/orders.blade.php ENDPATH**/ ?>