<?php if(count($combo_offers) > 0): ?>

<section id="Best_seller">

    <div class="container">

        <div class="row">

            <div class="col-lg-10 m-auto">
                <div class="header text-center">
                    <h2>Combo Offer</h2>
                </div>
            </div>

        </div>

        <!-- Category Content-->
        <div class="category_content">

            <div class="row">

                <?php $__currentLoopData = $combo_offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-sm-4">

                        <div class="category_item">

                            <div class="img">
                                <img src="frontend_asset/images/category_item1.png" class="img-fluid w-100" alt="">
                            </div>

                            <div class="text">
                                <h3 class="wh"><?php echo e($offer->name); ?></h3>
                                <p class="wh"><del>৳ <?php echo e(number_format($offer->grand_price, 2)); ?></del> ৳ <?php echo e(discounted_price($offer->grand_price, $offer->discount)); ?></p>

                                <div class="add_to_cart d_flex d_justify">
                                    <a href="<?php echo e(route('offer.details', $offer->slug)); ?>">View More</a>
                                    <a href="">Order Now</a>
                                </div>

                            </div>

                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>

        </div>

    </div>

</section>

<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\laravel_project\Diamond-Zone\resources\views/theme/includes/combo_offer_section.blade.php ENDPATH**/ ?>