<div class="col-lg-3">

    <div class="user_dashboard_list">

        <nav>
            <div class="nav nav-tabs" id="nav-tab" role="tablist">

                
                <button class="nav-link <?php echo $__env->yieldContent('dashboard'); ?>">
                    <a href="<?php echo e(route('user.dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                </button>

                
                <button class="nav-link <?php echo $__env->yieldContent('order'); ?>">
                    <a href="<?php echo e(route('user.orders')); ?>"><i class="fas fa-shopping-bag"></i> Orders</a>
                </button>


                
                <button class="nav-link <?php echo $__env->yieldContent('account'); ?>">
                    <a href="<?php echo e(route('user.accounts')); ?>"><i class="fas fa-user"></i> Account details</a>
                </button>

                
                <button class="nav-link">
                    <a onclick="event.preventDefault(); document.getElementById('frm-logout').submit();" href="<?php echo e(route('logout')); ?>"> <i class="fas fa-sign-out-alt"></i> Logout </a>
                    <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </button>


            </div>
        </nav>


    </div>

</div>
<?php /**PATH D:\xampp\htdocs\laravel_project\Diamond-Zone\resources\views/theme/user/sidebar.blade.php ENDPATH**/ ?>