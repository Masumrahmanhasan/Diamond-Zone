


<?php $__env->startSection('content'); ?>
		<div class="category_page">


				<section id="banner">

						<div class="banner_img">
								<a href="">
										<img src="<?php echo e(asset('frontend_asset/images/category_banner.jpg')); ?>" class="img-fluid w-100" alt="">
								</a>
						</div>

						<div class="banner_overlay">
								<h2 class="wh">Shop</h2>
						</div>

				</section>


				<!-- Section gaps -->
				<div class="section_gaps"></div>



				<div class="section_gaps"></div>

				<!-- ---------------------------------------------------------------------------------------------------------------------------------------------------
						START Content part PART
		---------------------------------------------------------------------------------------------------------------------------------------------------  -->
				<section id="Category">

						<div class="container">

								<!-- Header -->
								<div class="row">

										<div class="col-lg-12">

												<div class="header d_flex d_justify">

														<p>Showing <?php echo e($shop_products->count()); ?> results Sort by latest Sale!</p>

														<!-- Filter -->
														<div class="filter">

																<select name="">

																		<option value="">Short by latest</option>
																		<option value="">Short by popularity</option>
																		<option value="">Short by avarage rating</option>

																</select>

														</div>

												</div>

										</div>

								</div>

								<!-- Category Content-->
								<div class="category_content">

										<div class="row">

												<?php $__currentLoopData = $shop_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<!-- item -->
														<div class="col-lg-3 col-sm-4">

																<div class="category_item">

																		<a href="categort_details.html">
																				<div class="img">
																						<img src="<?php echo e(uploaded_asset($product->thumbnail) ?? asset('frontend_asset/images/category_item1.png')); ?>" class="img-fluid w-100" alt="">
																				</div>

																		</a>

																		<div class="text">
																				<h3 class="wh"><?php echo e($product->name); ?></h3>
																				<p class="wh">

                                                                                    <?php if($product->discount != 0): ?>
                                                                                    <del>৳ <?php echo e(number_format($product->price, 2)); ?></del> ৳ <?php echo e(number_format(($product->price - $product->discount), 2)); ?>

                                                                                    <?php else: ?>
                                                                                    ৳ <?php echo e(number_format($product->price, 2)); ?>

                                                                                    <?php endif; ?>
                                                                                </p>

																				<div class="add_to_cart d_flex d_justify">
																						<a href="<?php echo e(route('product_details', $product->slug)); ?>">View More</a>
																						<a href="javascript:;" onclick="buyNow(<?php echo e($product->id); ?>, false)">Order Now</a>
																				</div>

																		</div>

																		<!-- overlay -->
																		<div class="overlay">
																				<span>Sale</span>
																		</div>

																</div>

														</div>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



										</div>

								</div>

						</div>

				</section>

		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_project\Diamond-Zone\resources\views/theme/product_listing.blade.php ENDPATH**/ ?>