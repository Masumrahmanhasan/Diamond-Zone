<section id="stayUpdate">

    <!-- dash -->
    <div class="dash">

        <div class="img">
            <i class="fas fa-gem"></i>
        </div>

    </div>

    <!-- Section gaps -->
    <div class="section_gaps"></div>

    <!-- Content -->
    <div class="container">

        <div class="row">

            <div class="col-lg-10 m-auto">

               <div class="header text-center">
                    <h3 >Stay Updated With the Latest...</h3>
                    <div class="social_part d_flex">
                        <a href="<?php echo e(get_setting('facebook_link')); ?>" target="_blank" class="d_flex"><i class="fab fa-facebook-f"></i></a>
                        <a href="<?php echo e(get_setting('youtube_link')); ?>" target="_blank" class="d_flex"><i class="fab fa-youtube"></i></a>
                        <a href="<?php echo e(get_setting('twitter_link')); ?>" target="_blank" class="d_flex"><i class="fab fa-twitter"></i></a>
                        <a href="<?php echo e(get_setting('instagram_link')); ?>" target="_blank" class="d_flex"><i class="fab fa-instagram"></i></a>
                        <a href="<?php echo e(get_setting('linkedin_link')); ?>" target="_blank" class="d_flex"><i class="fab fa-linkedin-in"></i></a>
                    </div>
               </div>

            </div>

        </div>

    </div>

</section>
<?php /**PATH D:\xampp\htdocs\laravel_project\Diamond-Zone\resources\views/theme/includes/social_media_section.blade.php ENDPATH**/ ?>