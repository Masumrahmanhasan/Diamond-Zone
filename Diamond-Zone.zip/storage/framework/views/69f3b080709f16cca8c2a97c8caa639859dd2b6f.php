

<?php $__env->startSection('content'); ?>
<div class="row mt-4">

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
            <div class="d-block mb-4 mb-md-0">

                    <h2 class="h4">Profile Settings</h2>

            </div>

    </div>
        <div class="col-8 mb-4 mx-auto">
            <div class="card border-0 shadow components-section">
                    <div class="card-header">
                        Save & Change Your Password
                    </div>
                    <div class="card-body">

                            <form action="<?php echo e(route('profile.update_settings')); ?>" method="POST">
                                <?php echo csrf_field(); ?>


                                <div class="form-group row mb-3">
                                    <label class="col-md-3 col-from-label">Name</label>
                                    <div class="col-md-8">
                                        <div class="form-group">

                                            <input type="text" class="form-control" placeholder="name" name="name" value="<?php echo e(auth()->user()->name); ?>">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row mb-3">
                                    <label class="col-md-3 col-from-label">Email</label>
                                    <div class="col-md-8">
                                        <div class="form-group">

                                            <input type="text" class="form-control" placeholder="email" name="email" value="<?php echo e(auth()->user()->email); ?>">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row mb-3">
                                    <label class="col-md-3 col-from-label">Phone Number</label>
                                    <div class="col-md-8">
                                        <div class="form-group">

                                            <input type="text" class="form-control" placeholder="phone number" name="phone" value="<?php echo e(auth()->user()->phone); ?>">
                                        </div>
                                    </div>
                                </div>

                                <div class="text-end">
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>

                            </form>

                    </div>
            </div>
        </div>
        <div class="col-8 mb-4 mx-auto">
                <div class="card border-0 shadow components-section">
                        <div class="card-header">
                            Save & Change Your Password
                        </div>
                        <div class="card-body">

                                <form action="<?php echo e(route('profile.update_password')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>


                                    <div class="form-group row mb-3">
                                        <label class="col-md-3 col-from-label">Old Password</label>
                                        <div class="col-md-8">
                                            <div class="form-group">

                                                <input type="password" class="form-control <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    is-invalid
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Current Password" name="old_password" value="">
                                            </div>
                                            <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            <?php if(Session::has('error')): ?>
                                            <span class="text-danger"><?php echo e(Session::get('error')); ?></span>
                                            <?php endif; ?>

                                        </div>
                                    </div>

                                    <div class="form-group row mb-3">
                                        <label class="col-md-3 col-from-label">New Password</label>
                                        <div class="col-md-8">
                                            <div class="form-group">

                                                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                is-invalid
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="New Password" name="password" id="password" value="">
                                            </div>

                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>
                                    </div>

                                    <div class="form-group row mb-3">
                                        <label class="col-md-3 col-from-label">Confirm Password</label>
                                        <div class="col-md-8">
                                            <div class="form-group">

                                                <input type="password" class="form-control" placeholder="Confirm Password" id="password_confirmation" name="password_confirmation" value="">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="text-end">
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>

                                </form>

                        </div>
                </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_project\Diamond-Zone\resources\views/admin/settings/password_change.blade.php ENDPATH**/ ?>