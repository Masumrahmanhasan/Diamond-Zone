

<?php $__env->startSection('content'); ?>
		<div class="row mt-4">

				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
						<div class="d-block mb-4 mb-md-0">

								<h2 class="h4">Create New Category</h2>

						</div>

				</div>
				<div class="col-6 mb-4">
						<div class="card border-0 shadow components-section">
								<div class="card-body">
										<div class="row mb-4">
                                            <form action="<?php echo e(route('categories.store')); ?>" method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
												<div class="col-lg-12 col-sm-6">
														<div class="mb-4">
																<label for="email">Category Name</label>
                                                                <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                is-invalid
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
																		id="category_name">
                                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <small class="form-text invalid-feedback"><?php echo e($message); ?></small>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
														</div>

														<div class="mb-4">
																<label for="email">Category Slug</label>
																<input type="text" name="slug" class="form-control" id="category_slug"
																		readonly>

														</div>

														<div class="mb-4">
																<div class="card card-body border-dashed shadow mb-4 <?php $__errorArgs = ['featured_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

																		<h2 class="h5 mb-4">Select Category Image</h2>
																		<div class="d-flex align-items-center">

																				<div class="me-3">
                                                                                <img class="rounded avatar-xl"
																								src="<?php echo e(asset('img/category_placeholder.png')); ?>" id="preview-image" alt="change avatar"></div>
																				<div class="file-field">

																						<div class="d-flex justify-content-xl-center ms-xl-3">
																								<div class="d-flex">
                                                                                                        <svg class="icon text-gray-500 me-2" fill="currentColor"
																												viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
																												<path fill-rule="evenodd"
																														d="M8 4a3 3 0 00-3 3v4a5 5 0 0010 0V7a1 1 0 112 0v4a7 7 0 11-14 0V7a5 5 0 0110 0v4a3 3 0 11-6 0V7a1 1 0 012 0v4a1 1 0 102 0V7a3 3 0 00-3-3z"
																														clip-rule="evenodd"></path>
																										</svg>
                                                                                                        <input type="file" name="featured_image" id="photo" >
																										<div class="d-md-block text-left">
																												<div class="fw-normal text-dark mb-1">Choose Image</div>
																												<div class="text-gray small">JPG, PNG, Or SVG. Max size of 800K</div>
																										</div>
																								</div>
																						</div>
																				</div>
																		</div>
																</div>

                                                                <?php $__errorArgs = ['featured_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <small class="form-text text-danger"><?php echo e($message); ?></small>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
														</div>

														<div class="mt-3">
                                                            <button type="submit" class="btn btn-gray-800 mt-2 animate-up-2">Save All</button>
                                                        </div>
												</div>
                                            </form>

										</div>

								</div>
						</div>
				</div>
		</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
		<script>
		  var category_name = document.getElementById('category_name');
		  var category_slug = document.getElementById('category_slug');

		  category_name.addEventListener('keyup', function() {
		    category_slug.value = slugify(category_name.value)
		  })


		</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_project\Diamond-Zone\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>