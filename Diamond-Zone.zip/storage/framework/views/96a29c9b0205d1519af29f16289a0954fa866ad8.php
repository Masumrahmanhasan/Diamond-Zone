<?php $__env->startSection('content'); ?>
    <div class="category_page">

        <section id="product_details">

            <div class="container">

                <!-- Header -->
                <div class="row">

                    <div class="col-lg-6">

                        <div class="header mt-3">
                            <h4 style="color: #7c9dec;">Home / <?php echo e($product->category->name); ?> / <?php echo e($product->name); ?> -
                                <?php echo e($product->sku); ?></h4>
                        </div>

                    </div>

                </div>

                <!-- Product Details Content -->
                <div class="product_details_content">

                    <div class="row">

                        <!-- Image Part -->
                        <div class="col-lg-6">

                            <span class='zoom' id='ex1'>

                                <img src='<?php echo e(uploaded_asset($product->thumbnail)); ?>'
                                    xoriginal="<?php echo e(uploaded_asset($product->thumbnail)); ?>" class="xzoom"
                                    alt='Daisy on the Ohoopee' />


                                <div class="xzoom-thumbs">
                                    <a href="<?php echo e(uploaded_asset($product->thumbnail)); ?>">
                                        <img class="xzoom-gallery" width="80"
                                            src="<?php echo e(uploaded_asset($product->thumbnail)); ?>"
                                            xpreview="<?php echo e(uploaded_asset($product->thumbnail)); ?>">
                                    </a>

                                    <?php $__currentLoopData = explode(',', $product->gallary); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(uploaded_asset($gallary)); ?>">
                                            <img class="xzoom-gallery" width="80"
                                                src="<?php echo e(uploaded_asset($gallary)); ?>">
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>
                            </span>

                        </div>

                        <!-- Product Description -->
                        <div class="col-lg-6">

                            <div class="product_description">

                                <h3><?php echo e($product->name); ?> <?php echo e($product->sku); ?></h3>

                                <ul>
                                    <?php echo $product->short_description; ?>

                                </ul>

                                <!-- Amounnt -->
                                <div class="amount">

                                    <?php if($product->discount != 0): ?>
                                        <h3>
                                            <del>৳ <?php echo e(number_format($product->price, 2)); ?></del>
                                        </h3>
                                        <h3>৳ <?php echo e(number_format($product->price - $product->discount, 2)); ?></h3>
                                    <?php else: ?>
                                        <h3>৳ <?php echo e(number_format($product->price, 2)); ?></h3>
                                    <?php endif; ?>

                                </div>

                                <!-- add to cart -->
                                <div class="add_to_cart d_flex">

                                    <div class="custome_input">
                                        <input type="number" id="quantity" value="1" name="" min="1">
                                    </div>

                                    <a href="javascript:;" onclick="buyNow(<?php echo e($product->id); ?>, false)"> Order Now </a>

                                </div>

                                <!-- Category -->
                                <div class="category_text">

                                    <div class="category_items d_flex">
                                        <h5>SKU</h5>
                                        <span><?php echo e($product->sku); ?></span>
                                    </div>

                                    <div class="category_items d_flex">
                                        <h5>Category</h5>
                                        <span><?php echo e($product->category->name); ?></span>
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

            <!-- Review & Conditions -->
            <div class="review_Condition">

                <div class="container">

                    <div class="row">

                        <div class="col-lg-12">

                            <div class="product_tabs">

                                <!-- Tabs Button -->
                                <ul class="nav nav-tabs" id="myTab" role="tablist">

                                    <!-- DESCRIPTION -->
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="description-tab" data-bs-toggle="tab"
                                            data-bs-target="#description" type="button" role="tab"
                                            aria-controls="description" aria-selected="true">DESCRIPTION</button>
                                    </li>

                                    <!-- International Information -->
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="International-tab" data-bs-toggle="tab"
                                            data-bs-target="#International" type="button" role="tab"
                                            aria-controls="International" aria-selected="false">INTERNATIONAL
                                            INFORMATION</button>
                                    </li>

                                    <!-- Review -->
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="Review-tab" data-bs-toggle="tab"
                                            data-bs-target="#Review" type="button" role="tab" aria-controls="Review"
                                            aria-selected="false">REVIEWS</button>
                                    </li>

                                </ul>

                                <!-- Tabs Item -->


                                <div class="tab-content" id="myTabContent">

                                    <!-- Description -->
                                    <div class="tab-pane fade show active" id="description" role="tabpanel"
                                        aria-labelledby="description-tab">

                                        <div class="row">

                                            <!-- Descripntion -->
                                            <div class="col-lg-6">
                                                <?php echo $product->description; ?>


                                            </div>

                                            <div class="col-lg-6">

                                                <div class="img">
                                                    <img src="<?php echo e(uploaded_asset($product->certificate)); ?>"
                                                        class="img-fluid" alt="">
                                                </div>

                                            </div>



                                        </div>

                                    </div>

                                    <!-- International Information -->
                                    <div class="tab-pane fade" id="International" role="tabpanel"
                                        aria-labelledby="International-tab">

                                        <div class="row">

                                            <!-- Descripntion -->
                                            <div class="col-lg-6">
                                                <?php echo $product->description; ?>


                                            </div>

                                            <div class="col-lg-6">

                                                <div class="img">
                                                    <img src="<?php echo e(uploaded_asset($product->certificate)); ?>"
                                                        class="img-fluid" alt="">
                                                </div>

                                            </div>



                                        </div>

                                    </div>

                                    <!-- Review -->
                                    <div class="tab-pane fade" id="Review" role="tabpanel"
                                        aria-labelledby="Review-tab">

                                        <h3>Reviews</h3>

                                        <?php if(auth()->guard()->check()): ?>
                                            <ul>
                                                <li>There are no reviews yet.</li>
                                                <li>Be the first to review “DIAMOND PENDANT DP-0121”</li>
                                                <li>Your email address will not be published. Required fields are marked *</li>
                                            </ul>
                                            <?php
                                                $order = App\Models\Order::with('order_items')
                                                    ->where('user_id', Auth::user()->id)
                                                    ->first();
                                            ?>

                                            <?php if($order): ?>
                                                <?php $__currentLoopData = $order->order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($item->product_id == $product->id): ?>
                                                        <?php
                                                            $review = App\Models\Review::where('product_id', $product->id)
                                                                ->where('user_id', Auth::user()->id)
                                                                ->first();
                                                        ?>

                                                        <?php if($review): ?>
                                                            <p class="text-warning">You Have Already Submited a review</p>
                                                        <?php else: ?>
                                                            
                                                            <form action="<?php echo e(route('product.review_store')); ?>"
                                                                method="POST" enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="product_id"
                                                                    value="<?php echo e($product->id); ?>">
                                                                <!-- Rating -->
                                                                <div class="form-group">
                                                                    <label class="opacity-60">Rating</label>
                                                                    <div class="rating rating-input c-pointer">
                                                                        <label>
                                                                            <input type="radio" name="rating"
                                                                                value="1" required="">
                                                                            <i class="fas fa-star"></i>
                                                                        </label>
                                                                        <label>
                                                                            <input type="radio" name="rating"
                                                                                value="2">
                                                                            <i class="fas fa-star"></i>
                                                                        </label>
                                                                        <label>
                                                                            <input type="radio" name="rating"
                                                                                value="3">
                                                                            <i class="fas fa-star"></i>
                                                                        </label>
                                                                        <label>
                                                                            <input type="radio" name="rating"
                                                                                value="4">
                                                                            <i class="fas fa-star"></i>
                                                                        </label>
                                                                        <label>
                                                                            <input type="radio" name="rating"
                                                                                value="5">
                                                                            <i class="fas fa-star"></i>
                                                                        </label>
                                                                    </div>
                                                                </div>

                                                                <div class="form_part">
                                                                    <div class="custome_input">
                                                                        <input type="file" name="attachment">
                                                                    </div>
                                                                </div>

                                                                <!-- Form Part -->
                                                                <div class="form_part">

                                                                    <div class="custome_input">
                                                                        <label>Comment *</label>
                                                                        <textarea name="body" id="" rows="3"></textarea>
                                                                    </div>

                                                                    <div class="custome_input">
                                                                        <button type="submit">Submit</button>
                                                                    </div>

                                                                </div>

                                                            </form>
                                                            
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </section>
    </div>


    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(".xzoom, .xzoom-gallery").xzoom({
            tint: '#333',
            Xoffset: 15
        });

        $(document).ready(function() {
            $(".rating-input").each(function() {
                $(this)
                    .find("label")
                    .on({
                        mouseover: function(event) {
                            $(this).find("svg").addClass("hover");
                            $(this).prevAll().find("svg").addClass("hover");
                        },
                        mouseleave: function(event) {
                            $(this).find("svg").removeClass("hover");
                            $(this).prevAll().find("svg").removeClass("hover");
                        },
                        click: function(event) {
                            $(this).siblings().find("svg").removeClass("active");
                            $(this).find("svg").addClass("active");
                            $(this).prevAll().find("svg").addClass("active");
                        },
                    });
                if ($(this).find("input").is(":checked")) {
                    $(this)
                        .find("label")
                        .siblings()
                        .find("svg")
                        .removeClass("active");
                    $(this)
                        .find("input:checked")
                        .closest("label")
                        .find("svg")
                        .addClass("active");
                    $(this)
                        .find("input:checked")
                        .closest("label")
                        .prevAll()
                        .find("svg")
                        .addClass("active");
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_project\Diamond-Zone\resources\views/theme/product_details.blade.php ENDPATH**/ ?>