<section id="customer_review">

    <div class="container">

        <!-- Header -->
        <div class="row">

            <div class="col-lg-10 m-auto">
                <div class="header text-center">
                    <h2>CUSTOMER REVIEWS</h2>
                </div>
            </div>

        </div>

        <!-- Customer Review Content -->
        <div class="customer_review_content">

            <div class="row">
                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <!-- Item -->
                    <div class="col-lg-4 col-sm-4">

                        <div class="customer_review_item">

                            <div class="img"><i class="fas fa-gem"></i></div>

                            <div class="text">
                                <p class="wh"><?php echo e($review->body); ?></p>
                                <h3 class="wh"><?php echo e($review->user->name); ?></h3>
                            </div>

                        </div>

                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>

    </div>

</section>
<?php /**PATH D:\xampp\htdocs\laravel_project\Diamond-Zone\resources\views/theme/includes/customer_review_section.blade.php ENDPATH**/ ?>