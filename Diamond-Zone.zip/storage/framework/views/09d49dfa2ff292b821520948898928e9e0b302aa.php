<?php $__env->startSection('content'); ?>
<section id="banner">


    <?php if(get_setting('home_slider_images') != null): ?>
    <?php $slider_images = json_decode(get_setting('home_slider_images'), true);  ?>
    <div class="owl-carousel owl-theme">

        <!-- Item -->
        <?php $__currentLoopData = $slider_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item">
            <div class="banner_img">
                <a href="<?php echo e(json_decode(get_setting('home_slider_links'), true)[$key]); ?>">
                    <img src="<?php echo e(uploaded_asset($slider_images[$key])); ?>" class="img-fluid w-100" alt="">
                </a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <?php endif; ?>


</section>



<div class="section_gaps"></div>

<?php echo $__env->make('theme.includes.category_section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="section_gaps"></div>

<?php echo $__env->make('theme.includes.best_seller_section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="section_gaps"></div>

<?php echo $__env->make('theme.includes.combo_offer_section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="section_gaps"></div>

<?php echo $__env->make('theme.includes.customer_review_section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="section_gaps"></div>

<?php echo $__env->make('theme.includes.photo_review_section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="section_gaps"></div>

<?php echo $__env->make('theme.includes.video_section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="section_gaps"></div>

<?php echo $__env->make('theme.includes.social_media_section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_project\Diamond-Zone\resources\views/theme/home.blade.php ENDPATH**/ ?>