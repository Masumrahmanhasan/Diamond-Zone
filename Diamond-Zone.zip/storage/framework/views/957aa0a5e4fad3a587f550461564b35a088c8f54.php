<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Diamond Zone')); ?></title>


    <!-- Font Link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=PT+Sans:wght@400;700&display=swap" rel="stylesheet">


    <link rel="stylesheet" href="<?php echo e(asset('frontend_asset/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend_asset/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend_asset/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend_asset/css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend_asset/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend_asset/css/style.css')); ?>">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('frontend_asset/css/media.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/simple-notify@0.5.5/dist/simple-notify.min.css" />
    <link rel="stylesheet" href="https://unpkg.com/xzoom/dist/xzoom.css">

    <?php echo $__env->yieldContent('styles'); ?>


</head>
<body>

    <div id="app">


        <div class="preloader">
            <img src="frontend_asset/images/preloader.gif" alt="">
        </div>

        <section id="singUp">

            <div class="container">

                <div class="row">

                    <div class="col-lg-6">

                        <div class="sing_number">
                            <a href="tel:<?php echo e(get_setting('helpline_number')); ?>"><i class="fas fa-phone-alt"></i> <?php echo e(get_setting('helpline_number')); ?></a>
                        </div>

                    </div>

                    <div class="col-lg-6">

                        <div class="singUp_content d_flex">

                            <form action="" method="POST">

                                <div class="custome_input">
                                    <input type="text">

                                    <div class="search">
                                        <i class="fas fa-search"></i>
                                    </div>

                                </div>

                            </form>

                            <div class="sign_in dropdown show">
                                <?php if(auth()->guard()->check()): ?>
                                <a href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-home"></i> My Account
                                </a>

                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                        <?php if(auth()->user()->user_type == 'admin'): ?>
                                        <a class="dropdown-item" style="color: black !important" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>

                                        <?php else: ?>
                                            <a class="dropdown-item" style="color: black !important" href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a>
                                            <a class="dropdown-item" style="color: black !important" href="<?php echo e(route('user.orders')); ?>">My Order</a>
                                        <?php endif; ?>

                                        <a class="dropdown-item" style="color: black !important" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Logout</a>
                                    </div>
                                <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>">
                                    <i class="fas fa-user-circle"></i> Sign In
                                </a>
                                <?php endif; ?>

                            </div>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>

                    </div>

                </div>

            </div>

        </section>

        

        <?php
            $categories = \App\Models\Category::with('subcategory')->take(5)->get();
        ?>
        <nav class="navbar navbar-expand-lg">

            <div class="container">

                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(uploaded_asset(get_setting('header_logo')) ?? asset('frontend_asset/images/logo.svg')); ?>" alt="">
                </a>

                <!-- Mobile Menu -->
                <div class="mobileMenu">

                    <a class="" data-bs-toggle="offcanvas" href="#offcanvasExample" role="button" aria-controls="offcanvasExample">
                        <i class="fas fa-bars"></i>
                    </a>


                    <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">

                        <div class="offcanvas-header">
                          <h2 class="offcanvas-title" id="offcanvasExampleLabel">Menu Bar</h2>
                          <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                        </div>

                        <div class="offcanvas-body">

                            <div class="dropdown mt-3">
                                <ul class="navbar-nav ms-auto">

                                    <li class="nav-item">
                                        <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>">HOME</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('shop')); ?>">SHOP</a>
                                    </li>

                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">

                                        <a class="nav-link <?php if(count($category->subcategory) > 0): ?> dropdown-toggle <?php endif; ?>" href="<?php echo e(route('product_by_category', $category->slug)); ?>" <?php if(count($category->subcategory) > 0): ?> id="dropdownMenuButton" data-bs-toggle="dropdown" <?php endif; ?>>
                                            <?php echo e($category->name); ?>

                                        </a>

                                            <?php if(count($category->subcategory) > 0): ?>
                                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <?php $__currentLoopData = $category->subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a class="dropdown-item" href="#"><?php echo e($subcategory->name); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                            <?php endif; ?>

                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </ul>
                            </div>
                        </div>

                    </div>

                </div>

                <div class="collapse navbar-collapse" id="navbarNavDropdown">

                    <ul class="navbar-nav ms-auto">

                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="<?php echo e(route('master')); ?>">HOME</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('shop')); ?>">SHOP</a>
                        </li>

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">

                                <a class="nav-link" href="<?php echo e(route('product_by_category', $category->slug)); ?>"><?php echo e($category->name); ?></a>

                                <?php if(count($category->subcategory) > 0): ?>
                                    <ul class="drop_down">

                                        <?php $__currentLoopData = $category->subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href=""><?php echo e($subcategory->name); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                <?php endif; ?>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>

                </div>

            </div>

        </nav>

            <?php echo $__env->yieldContent('content'); ?>

            <div class="section_gaps"></div>

            <?php echo $__env->make('theme.includes.footer_section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <a class="backToTop">
                <i class="fas fa-chevron-up"></i>
            </a>
    </div>


    <div class="modal_part">

        <div class="modal fade " id="checkout_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog modal-dialog-centered modal-xl">

                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div id="checkout-modal-body">

                    </div>

                </div>
            </div>
        </div>

    </div>



    <script src="<?php echo e(asset('frontend_asset/js/jquery-1.12.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend_asset/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend_asset/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend_asset/js/slick.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend_asset/js/font-awesome.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend_asset/js/shop.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend_asset/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend_asset/js/jquery.elevatezoom.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend_asset/js/parsley.min.js')); ?>"></script>
    <script>

            // $('#orderform_for_from_submit').parsley();

    </script>

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-notify@0.5.5/dist/simple-notify.min.js"></script>

    <script src="https://unpkg.com/xzoom/dist/xzoom.min.js"></script>

    <script>
        AOS.init();
    </script>

    <script>
        <?php if(session()->has('message')): ?>
            showToast('warning', 'Warning', <?php echo e(session()->get('message')); ?>);
        <?php else: ?>

        <?php endif; ?>


        function buyNow(id, offer){

            if(offer == true){
                offer = 1
            } else {
                offer = 0
            }

            console.log(offer);

            <?php if(auth()->check() && (auth()->user()->user_type == 'user')): ?>

                var quantity = $('#quantity').val();

                $.post('<?php echo e(route('checkout.buyNow')); ?>', {_token: '<?php echo e(csrf_token()); ?>', id:id, quantity: quantity, offer:offer}, function(data){

                    $('#checkout-modal-body').html(data);
                    $('#checkout_modal').modal('show');

                });
            <?php else: ?>
                showToast('warning', 'Warning', 'Please Login First');
            <?php endif; ?>
        }

        function showToast(status, title, text){
            new Notify({
                status: status,
                title: title,
                text: text,
                effect: 'slide',
                speed: 300,
                customClass: null,
                customIcon: null,
                showIcon: true,
                showCloseButton: true,
                autoclose: true,
                autotimeout: 3000,
                gap: 20,
                distance: 20,
                type: 2,
                position: 'right top'
            })
        }


    </script>


    <?php echo $__env->yieldContent('scripts'); ?>


</body>
</html>
<?php /**PATH D:\xampp\htdocs\laravel_project\Diamond-Zone\resources\views/layouts/app.blade.php ENDPATH**/ ?>