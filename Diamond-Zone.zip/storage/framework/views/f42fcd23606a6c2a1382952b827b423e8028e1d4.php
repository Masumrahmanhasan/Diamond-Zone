<section id="shopByCategory">

    <div class="container">

        <div class="row">

            <div class="col-lg-10 m-auto">

                <div class="header text-center">
                    <h1>SHOP BY CATEGORY</h1>
                </div>

            </div>

        </div>

        <!-- content -->
        <div class="shopByCategory_content">

            <div class="row">

                <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <div class="<?php if($key+1 == 1 || $key+1 == 2): ?>col-lg-6 col-sm-6 <?php else: ?> col-lg-4 col-sm-4 <?php endif; ?>">

                        <div class="shopByCategory_item">

                            <a href="<?php echo e(route('product_by_category', $category->slug)); ?>">
                                <div class="shopByCategory_img">
                                    <img src="<?php echo e($category->featured_image); ?>" class="img-fluid w-100" alt="">
                                </div>
                            </a>

                        </div>

                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div>

        </div>

    </div>

</section>
<?php /**PATH D:\xampp\htdocs\laravel_project\Diamond-Zone\resources\views/theme/includes/category_section.blade.php ENDPATH**/ ?>