<section id="video_part">

    <div class="container">

        <!-- video_part content -->
        <div class="row d_flex">

            <div class="col-lg-8 col-sm-8">

                <!-- video -->
                <div class="video_part_content">

                    <div class="video">
                        <iframe width="100%" height="500" src="https://www.youtube.com/embed/r41QIqxtL_Q" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>

                </div>

            </div>

            <!-- text -->
            <div class="col-lg-4 col-sm-4">

                <div class="video_part_content">
                    <div class="text">
                        <h2>DIAMOND ZONE</h2>
                        <p>Make Your Luxury Style!</p>
                        <a href="{{ route('shop') }}">Browse All Collection</a>
                    </div>
                </div>

            </div>

        </div>

    </div>

</section>
